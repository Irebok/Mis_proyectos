package Actores;

import java.text.DecimalFormat;

public class Pelicula {

	private String titulo, nacionalidad;
	private int ID;
	private double interes;

	public Pelicula(String Titulo, String Nacionalidad, int ID, double Interes){
		
		if ((Interes > 5) || (Interes < 0)){
			System.out.println("La valoración de la película tiene que ser un valor entre 0.0 y 5.0");
			return;
		} else {
			this.titulo = Titulo;
			this.ID = ID;
			this.nacionalidad = Nacionalidad;
			this.interes = Interes;
		}
	}
	
	public void setTitulo(String Titulo){
		this.titulo = Titulo;
	}
	
	public void setNacionalidad(String Nacionalidad){
		this.nacionalidad = Nacionalidad;
	}
	
	public void setID(int ID){
		this.ID = ID;
	}
	
	public void setInteres(double Interes){
		if ((Interes > 5) || (Interes < 0)){
			System.out.println("La valoración de la película tiene que ser un valor entre 0.0 y 5.0");
			return;
		} else this.interes = Interes;
	}
	
	public String getTitulo(){
		return this.titulo;
	}
	
	public String getNacionalidad(){
		return this.nacionalidad;
	}
	
	public int getID(){
		return this.ID;
	}
	
	public String getInteres(){
		DecimalFormat df = new DecimalFormat("#.0"); 
		return df.format(this.interes);
	}
	
	public String toString(){
		
		DecimalFormat df = new DecimalFormat("#.0"); 
		String aux = "DESCRIPCIÓN DE LA PELÍCULA CON ID "+ this.ID + ": \n";
		
			aux = aux + "\tTítulo: '" + this.titulo + "'.\n";
			aux = aux + "\tNacionalidad: '" + this.nacionalidad + "'.\n";
			aux = aux + "\tInterés: '" + df.format(this.interes) + "'.\n\n";
		
		return aux;
	}
	
}
