package Gestión;
import Actores.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.Iterator;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.config.Configuration;


public class Gestor {

	public static void main(String[] args) throws IOException {
	
		boolean mantenerse = true;
		
		Configuration config = Db4o.configure();
		ObjectContainer db = Db4o.openFile(config, "practica6.db4o");

        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);
        String cadena = "";
        
        while(mantenerse){
        	
        	 System.out.print("Por favor, selecciona el ejercicio (salir = 100): ");
             cadena = br.readLine();
             
             switch(Integer.parseInt(cadena)){
             
             	case 100: {
             		mantenerse = false;
             		break;
             	}
             
             	case 1: {
             		ejercicio1(db);
             		break;
             	}
             	
             	case 2: {
             		ejercicio2(db);
             		break;
             	}
             	
             	case 3: {
             		ejercicio3(db);
             		break;
             	}
             	
             	case 4: {
             		ejercicio4(db, br);
             		break;
             	}
             	
             	default: {
             		System.out.println("Por favor, introduzca una operación correcta.");
             		break;             		
             	}
             }
        }
       		
		db.close();
		isr.close();
		br.close();
	}
	
	public static void ejercicio1(ObjectContainer db){
		Pelicula peliculaAux = new Pelicula("La dama y el vagamundo", "Estadounidense", 1, 3.2);
		db.store(peliculaAux);
		peliculaAux = new Pelicula("The Fast & The Furious", "Estadounidense", 2, 4.1);
		db.store(peliculaAux);
		peliculaAux = new Pelicula("El origen de los guardianes", "Inglesa", 3, 4.5);
		db.store(peliculaAux);
		peliculaAux = new Pelicula("Casi 300", "Danesa", 4, 2.0);
		db.store(peliculaAux);
		peliculaAux = new Pelicula("Primos", "Española", 5, 1.5);
		db.store(peliculaAux);
	}

	public static void ejercicio2(ObjectContainer db){
		
		ObjectSet<Pelicula> peliculasAux = db.queryByExample(Pelicula.class);

		System.out.println("CONSULTANDO LAS PELICULAS ALMACENADAS EN LA BASE DE DATOS: ");
		
		Iterator<Pelicula> it = peliculasAux.iterator();
		while (it.hasNext()){
			System.out.println(it.next());
		}
	}
	
	public static void ejercicio3(ObjectContainer db){
		
		ObjectSet<Pelicula> peliculasAux = db.queryByExample(new Pelicula(null, "Española", 0, 0.0));
		
		System.out.println("CONSULTANDO LAS PELICULAS ESPAÑOLAS ALMACENADAS EN LA BASE DE DATOS: ");
		
		Iterator<Pelicula> it = peliculasAux.iterator();
		while (it.hasNext()){
			System.out.println(it.next());
		}	
	}
	
	public static void ejercicio4(ObjectContainer db, BufferedReader brAux) throws IOException{
		
		boolean mantenerse = true;
		
		String cadenaAux = "";
		
		System.out.println("\n\nBIENVENIDO AL GESTOR DE PELÍCULAS. ¿QUÉ OPERACIÓN DESEA REALIZAR?");
		
		while (mantenerse){
			System.out.println("\t1. Añadir película.");
			System.out.println("\t2. Borrar película.");
			System.out.println("\t3. Listar películas.");
			System.out.println("\t4. Modificar película.");
			System.out.println("\t5. Volver al menú principal.");
			System.out.print("--> ");
			
			cadenaAux = brAux.readLine();
			
			switch(Integer.parseInt(cadenaAux)){
			 
		 	case 1: {
		 		anhadirPelicula(db, brAux);		 		
		 		break;
		 	}
		 	
		 	case 2: {
		 		borrarPelicula(db, brAux);		 		
		 		break;
		 	}
		 	
		 	case 3: {
		 		ejercicio2(db);
		 		break;
		 	}
		 	
		 	case 4: {
		 		modificarPelicula(db, brAux);
		 		break;		 		
		 	}
		 	
		 	case 5: {
		 		mantenerse = false;
		 		break;
		 	}
		 	
		 	default: {
		 		System.out.println("Por favor, introduzca una opicón válida.");
		 		break;
		 	} 		 
		 }
		}
	}
	
	public static void anhadirPelicula(ObjectContainer db, BufferedReader brAux) throws IOException{
		
 		System.out.println("\n\nAÑADIR PELÍCULA:");
 		
 		System.out.print("Por favor, introduzca el título de la película: ");
 		String titulo = brAux.readLine();
 		
 		System.out.print("\nPor favor, introduzca la nacionalidad de la película: ");
 		String nacionalidad = brAux.readLine();
 		
 		System.out.print("\nPor favor, introduzca un ID para la película: ");
 		int ID = Integer.parseInt(brAux.readLine());
 		
 		System.out.print("\nPor favor, introduzca una valoración para la película: ");
 		double interes = Double.parseDouble(brAux.readLine());
 		
 		db.store(new Pelicula(titulo, nacionalidad, ID, interes));
 		
 		System.out.println("Se ha añadido correctamente la película siguiente: " + new Pelicula(titulo, nacionalidad, ID, interes).toString());
 		
		
	}

	public static void borrarPelicula(ObjectContainer db, BufferedReader brAux) throws IOException{

		
 		System.out.println("\n\nBORRAR PELÍCULA(S):");
 		System.out.println("Por favor, introduzca los datos de la(s) película(s) que le interesa borrar. Si desconoce algún dato, introduzca un -1 en los campos numéricos o un salto del línea en los de texto.");
 		
 		System.out.print("Por favor, introduzca el título (texto): ");
 		String titulo = brAux.readLine();
 		if(titulo.trim().equals("")) titulo = null;
 		
 		System.out.print("Por favor, introduzca la nacionalidad (texto): ");
 		String nacionalidad = brAux.readLine();
 		if(nacionalidad.trim().equals("")) nacionalidad = null;
 		
 		System.out.print("Por favor, introduzca el ID (numérico): ");
 		int ID = Integer.parseInt(brAux.readLine());
 		if(ID == -1) ID = 0;
 		
 		System.out.print("Por favor, introduzca la valoración (numérico): ");
 		double interes = Double.parseDouble(brAux.readLine());
 		if(interes == -1) interes = 0.0;
 		
 		ObjectSet<Pelicula> peliculasAux = db.queryByExample(new Pelicula(titulo, nacionalidad, ID, interes));
 		
 		if(peliculasAux.isEmpty()){
 			System.out.println("No hay películas para eliminar.");
 			return; 			
 		} else {
 	 		Iterator<Pelicula> it = peliculasAux.iterator();
 	 		while (it.hasNext()){
 	 			Pelicula aux = it.next(); 	
 	 			
 	 			System.out.println("Se va a eliminar la película: " + aux.toString());
 	 			db.delete(aux);
 	 		}
 		}
	}
	
	public static void modificarPelicula(ObjectContainer db, BufferedReader brAux) throws IOException{
		
		System.out.println("\n\nMODIFICAR PELÍCULA(S):");
 		System.out.println("Por favor, introduzca los datos de la(s) película(s) que le interesa localizar para su modificación. Si desconoce algún dato, introduzca un -1 en los campos numéricos o un salto del línea en los de texto.");
 		
 		System.out.print("Por favor, introduzca el título (texto): ");
 		String titulo = brAux.readLine();
 		if(titulo.trim().equals("")) titulo = null;
 		
 		System.out.print("Por favor, introduzca la nacionalidad (texto): ");
 		String nacionalidad = brAux.readLine();
 		if(nacionalidad.trim().equals("")) nacionalidad = null;
 		
 		System.out.print("Por favor, introduzca el ID (numérico): ");
 		int ID = Integer.parseInt(brAux.readLine());
 		if(ID == -1) ID = 0;
 		
 		System.out.print("Por favor, introduzca la valoración (numérico): ");
 		double interes = Double.parseDouble(brAux.readLine());
 		if(interes == -1) interes = 0.0;
		
 		ObjectSet<Pelicula> peliculasAux = db.queryByExample(new Pelicula(titulo, nacionalidad, ID, interes));
 		
 		if(peliculasAux.isEmpty()){
 			System.out.println("No hay películas para modificar.");
 			return; 			
 		} else {
 			
 			System.out.println("Por favor, introduzca los datos nuevos. Si desea ignorar un dato, introduzca un -1 en los campos numéricos o un salto del línea en los de texto.");
 	 		
 	 		System.out.print("Por favor, introduzca el título (texto): ");
 	 		titulo = brAux.readLine();
 	 		if(titulo.trim().equals("")) titulo = null;
 	 		
 	 		System.out.print("Por favor, introduzca la nacionalidad (texto): ");
 	 		nacionalidad = brAux.readLine();
 	 		if(nacionalidad.trim().equals("")) nacionalidad = null;
 	 		
 	 		System.out.print("Por favor, introduzca el ID (numérico): ");
 	 		ID = Integer.parseInt(brAux.readLine());
 	 		
 	 		System.out.print("Por favor, introduzca la valoración (numérico): ");
 	 		interes = Double.parseDouble(brAux.readLine());
 			
 	 		Iterator<Pelicula> it = peliculasAux.iterator();
 	 		while (it.hasNext()){
 	 			Pelicula aux = it.next(); 	
 	 			
 	 			if (titulo != null) aux.setTitulo(titulo);
 	 			if (nacionalidad != null) aux.setNacionalidad(nacionalidad);
 	 			if (ID != -1) aux.setID(ID);
 	 			if (interes != -1) aux.setInteres(interes);
 	 			
 	 			db.store(aux);
 	 			System.out.println("Se ha actualizado una película, con el siguiente resultado: " + aux.toString());
 	 		}
 		}
	}
}
