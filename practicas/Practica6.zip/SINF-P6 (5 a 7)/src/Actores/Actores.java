package Actores;

import java.util.Vector;

public class Actores implements Comparable<Actores>{
	
	private int ID, edad;
	private String nombre = null, nacionalidad = null;
	private Vector<Peliculas> actuaEn = new Vector<Peliculas>();
		
	public Actores(int ID, String nombre, String nacionalidad, int edad){
		this.ID = ID;
		this.nombre = nombre;
		this.nacionalidad = nacionalidad;
		this.edad = edad;
	}

	public void setActor(Peliculas pelicula){
		this.actuaEn.add(pelicula);
	}
	
	public int getID() {
		return this.ID;
	}

	public void setID(int ID) {
		this.ID = ID;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getNacionalidad() {
		return this.nacionalidad;
	}

	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}

	public int getEdad() {
		return this.edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	public String toString(){
		
		String aux = "\nDATOS SOBRE EL ACTOR CON ID '" + this.ID + "':\n";
		
		aux = aux + "Nombre: " + this.nombre + ".\n";
		aux = aux + "Nacionalidad: " + this.nacionalidad + ".\n";
		aux = aux + "Edad: " + this.edad + ".\n";
		
		return aux;
	}

	@Override
	public int compareTo(Actores o) {
		if(getID()<o.getID()) return -1;
		else return 1;
	}
	

}
