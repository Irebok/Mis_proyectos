package Actores;

import java.util.Vector;

public class Directores implements Comparable<Directores>{

	private int ID, edad;
	private String nombre = null, nacionalidad = null;
	private Vector<Peliculas> dirige = new Vector<Peliculas>();
	
	public Directores(int ID, String nombre, String nacionalidad, int edad){
		this.ID = ID;
		this.nombre = nombre;
		this.nacionalidad = nacionalidad;
		this.edad = edad;
	}
	
	public void setPelicula(Peliculas pelicula){
		this.dirige.add(pelicula);
	}

	public int getID() {
		return ID;
	}

	public void setID(int ID) {
		this.ID = ID;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getNacionalidad() {
		return this.nacionalidad;
	}

	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}

	public int getEdad() {
		return this.edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	public String toString(){
		
		String aux = "\nDATOS SOBRE EL DIRECTOR CON ID '" + this.ID + "':\n";
		
		aux = aux + "Nombre: " + this.nombre + ".\n";
		aux = aux + "Nacionalidad: " + this.nacionalidad + ".\n";
		aux = aux + "Edad: " + this.edad + ".\n";
		
		return aux;
	}

	@Override
	public int compareTo(Directores o) {
		if(getID()<o.getID()) return -1;
		else return 1;
	}
	
	
}
