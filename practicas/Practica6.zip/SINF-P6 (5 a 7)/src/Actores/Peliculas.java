package Actores;

import java.util.Vector;

public class Peliculas implements Comparable<Peliculas>{
	
	private Directores director;
	private Vector<Actores> actores = new Vector<Actores>();
	private String titulo, nacionalidad;
	private int ID;

	public Peliculas (String Titulo, String Nacionalidad, int ID, Directores director, Vector<Actores> actores){
		this.titulo = Titulo;
		this.ID = ID;
		this.nacionalidad = Nacionalidad;
		this.director = director;
		this.actores = actores;
	}
	
	public Peliculas (String Titulo, String Nacionalidad, int ID, Directores director, Actores actor){
		this.titulo = Titulo;
		this.ID = ID;
		this.nacionalidad = Nacionalidad;
		this.director = director;
		this.actores.add(actor);
}
	
	public void setTitulo(String Titulo){
		this.titulo = Titulo;
	}
	
	public void setNacionalidad(String Nacionalidad){
		this.nacionalidad = Nacionalidad;
	}
	
	public void setID(int ID){
		this.ID = ID;
	}
	
	public void setDirector(Directores director){
		this.director = director;
	}
	
	public void setActor(Actores actor){
		this.actores.add(actor);
	}
	
	public void setActores(Vector<Actores> actores){
		this.actores.addAll(actores);
	}
	
	public String getTitulo(){
		return this.titulo;
	}
	
	public String getNacionalidad(){
		return this.nacionalidad;
	}
	
	public int getID(){
		return this.ID;
	}
	
	public Directores getDirector(){
		return this.director;
	}
	
	public Vector<Actores> getActores(){
		return this.actores;
	}
	
	public String toString(){
		String aux = "\nDATOS SOBRE LA PELÍCULA CON ID '" + this.ID + "':\n";
		
			aux = aux + "Título: " + this.titulo + ".\n";
			aux = aux + "Nacionalidad: " + this.nacionalidad + ".\n";
			aux = aux + "Director: " + this.director.getNombre() + ".\n";
			aux = aux + "Actores: " + this.actores.size() + ".\n";
		
		return aux;
	}

	@Override
	public int compareTo(Peliculas pel) {
		if(getID() < pel.getID()) return -1;
		else return 1;
	}
	
}
