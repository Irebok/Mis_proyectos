package Gestión;
import Actores.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.Iterator;
import java.util.Vector;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.config.Configuration;
import com.db4o.query.Predicate;
import com.db4o.query.Query;


public class Gestor {

	public static void main(String[] args) throws IOException {
	
		boolean mantenerse = true;
		
		Configuration config = Db4o.configure();
		ObjectContainer db = Db4o.openFile(config, "practica6-parte2.db4o");

        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);
        String cadena = "";
        
        while(mantenerse){
        	
        	 System.out.print("Por favor, selecciona el ejercicio (salir = 100): ");
             cadena = br.readLine();
             
             switch(Integer.parseInt(cadena)){
             
             	case 100: {
             		mantenerse = false;
             		break;
             	}
             
             	case 5: {
             		ejercicio5(db);
             		break;
             	}
             	
             	case 6: {
             		ejercicio6(db);
             		break;
             	}
             	
             	case 7: {
             		ejercicio7(db);
             		break;
             	}
              
             	default: {
             		System.out.println("Por favor, introduzca una operación correcta.");
             		break;             		
             	}
             }
        }
       		
		db.close();
		isr.close();
		br.close();
	}
	
	public static void ejercicio5(ObjectContainer db){
		
		Directores director = new Directores(1, "Tim Burton", "Estadounidense", 69);
		db.store(director);
		
		
		Vector<Actores> lista = new Vector<Actores>();
		
		Actores actor = new Actores(3, "Hugh Jackman", "Australiano", 48);
		db.store(actor);
		lista.add(actor);
		
		actor = new Actores(7, "Chris Pratt", "Irlandes", 37);
		db.store(actor);
		lista.add(actor);
		
		actor = new Actores(4, "Susan Sarandon", "Estadounidense", 62);
		db.store(actor);
		lista.add(actor);
		
		actor = new Actores(6, "Emma Stone", "Estadounidense", 32);
		db.store(actor);
		lista.add(actor);
		
		Peliculas pelicula = new Peliculas("Pulp Fiction", "Estadounidense", 1, director, lista);
		db.store(pelicula);
		
		actor = new Actores(2, "Gerard Butler", "Estadounidense", 38);
		db.store(actor);
		
		pelicula = new Peliculas("La novia cadaver", "Alemana", 4, director, actor);
		db.store(pelicula);
		
		director = new Directores(2, "Peter Jackson", "Neozelandes",  54);
		db.store(director);
		
		actor = new Actores(1, "Leonardo DiCaprio", "Estadounidense",  44);
		db.store(actor);
		
		pelicula = new Peliculas("Titanic", "Estadounidense", 3, director, actor);
		db.store(pelicula);
		
		director = new Directores(4, "Quentin Tarantino", "Estadounidense", 57);
		db.store(director);
		
		pelicula = new Peliculas("Les Miserables", "Francesa", 4,director, new Vector<Actores>());
		db.store(pelicula);
		
		director = new Directores(5, "Martin Scorsese", "Italiano", 81);
		db.store(director);
		
		actor = new Actores(5, "Emma Watson", "Britanica", 28);
		db.store(actor);
		
		pelicula = new Peliculas("El orfanato", "Española", 5, director, actor);
		db.store(pelicula);
		
		director = new Directores(3, "Stankey Kubrick", "Polaco", 45);
		db.store(director);
	}

	public static void ejercicio6(ObjectContainer db){
		
		ObjectSet<Peliculas> resultadoBusqueda = db.query(new Predicate<Peliculas>(){

			@Override
			public boolean match(Peliculas pelAux) {
				if(pelAux.getActores().size() > 3 && pelAux.getTitulo().length() > 10) return true;
				else return false;
			}

		});
		
		Iterator<Peliculas> it = resultadoBusqueda.iterator();
		while(it.hasNext()){
			System.out.println(it.next().toString());
		}
		
	}
	
	public static void ejercicio7(ObjectContainer db){
		
		Query query = db.query();
		
		query.descend("nacionalidad").constrain("Estadounidense").not().and(query.constrain(Actores.class).or(query.constrain(Directores.class)));
		
		ObjectSet<Object> lista = query.execute();
		Iterator<Object> it = lista.iterator();
		while(it.hasNext()) System.out.println(it.next().toString());
	}

}
